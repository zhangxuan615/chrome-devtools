var Panel = require("./app/components/Panel").default;

module.exports = { Panel };
