import "@testing-library/jest-dom";

import matchMedia from "./src/application/utilities/testing/matchMedia";

matchMedia();
