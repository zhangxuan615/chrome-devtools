import React from "react";

export function Loading() {
  return <p>Loading ...</p>;
}
