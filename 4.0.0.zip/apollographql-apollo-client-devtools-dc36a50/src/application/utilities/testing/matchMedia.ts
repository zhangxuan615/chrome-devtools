import MatchMediaMock from 'jest-matchmedia-mock';

const matchMediaMock = new MatchMediaMock();

export default () => matchMediaMock;
